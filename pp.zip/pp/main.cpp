#include "Game.h"


int main()
{
	//Create an object of controller
	Game game;

	game.go();
}
